logfile="/home/swalasavage/statuscheck.log"
echo " ">>$logfile
date  >>$logfile
echo " ">>$logfile



echo "Prod HSRM DB servers (instance and mirror status)">>$logfile
echo " ">>$logfile

DB01A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.68 "ccontrol qlist" | cut -d "^" -f 4`
DB01A_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.68 "ccontrol qlist" | cut -d "^" -f 12`

DB01A_PROD_STATES=`ssh -i swalasavage.pem swalasavage@10.247.78.68 "sudo csession VAHSRM001 -U %SYS "zproductionstatuses""`


echo "  db01a: Instance:       $DB01A_INST">>$logfile
echo "         Mirror status:  $DB01A_MIRR">>$logfile
echo "         Productions:    CCRAINT, HSVA, MVI, PPMS, ROUTER, HSRM">>$logfile
echo "                               $DB01A_PROD_STATES">>$logfile



#define eProductionStateUnknown        0
#define eProductionStateRunning        1
#define eProductionStateStopped        2
#define eProductionStateSuspended      3
#define eProductionStateTroubled       4
#define eProductionStateNetworkStopped 5




DB01B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.85 "ccontrol qlist" | cut -d "^" -f 4`
DB01B_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.85 "ccontrol qlist" | cut -d "^" -f 12`

echo "  db01b: Instance:       $DB01B_INST">>$logfile
echo "         Mirror status:  $DB01B_MIRR">>$logfile

echo " ">>$logfile

DB02B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.87 "ccontrol qlist" | cut -d "^" -f 4`
DB02B_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.87 "ccontrol qlist" | cut -d "^" -f 12`

echo "  db02b: Instance:       $DB02B_INST">>$logfile
echo "         Mirror status:  $DB02B_MIRR">>$logfile

echo " ">>$logfile
echo " ">>$logfile



echo "Prod HSRM Appservers (instance status)">>$logfile
echo " ">>$logfile

APP01A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.36 "ccontrol qlist" | cut -d "^" -f 4`
echo "  app01a:  $APP01A_INST">>$logfile

APP02A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.37 "ccontrol qlist" | cut -d "^" -f 4`
echo "  app02a:  $APP02A_INST">>$logfile

APP03A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.38 "ccontrol qlist" | cut -d "^" -f 4`
echo "  app03a:  $APP03A_INST">>$logfile

echo " ">>$logfile

APP01B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.52 "ccontrol qlist" | cut -d "^" -f 4`
echo "  app01b:  $APP01B_INST">>$logfile

APP02B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.53 "ccontrol qlist" | cut -d "^" -f 4`
echo "  app02b:  $APP02B_INST">>$logfile

APP03B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.54 "ccontrol qlist" | cut -d "^" -f 4`
echo "  app03b:  $APP03B_INST">>$logfile

echo " ">>$logfile
echo " ">>$logfile



echo "Prod HSIE servers (instance and mirror status)">>$logfile
echo " ">>$logfile

HSIEDB01A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.69 "ccontrol qlist" | cut -d "^" -f 4`
HSIEDB01A_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.69 "ccontrol qlist" | cut -d "^" -f 12`

HSIEDB01A_PROD_STATES=`ssh -i swalasavage.pem swalasavage@10.247.78.69 "sudo csession VAHSIE001 -U %SYS "zhsieproductionstatuses""`

echo "  hsiedb01a: Instance:       $HSIEDB01A_INST">>$logfile
echo "             Mirror status:  $HSIEDB01A_MIRR">>$logfile
echo "             Productions:    CCRAINT, HSREGISTRY">>$logfile
echo "                                   $HSIEDB01A_PROD_STATES">>$logfile



HSIEDB01B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.86 "ccontrol qlist" | cut -d "^" -f 4`
HSIEDB01B_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.86 "ccontrol qlist" | cut -d "^" -f 12`
echo "  hsiedb01b: Instance:       $HSIEDB01B_INST">>$logfile
echo "             Mirror status:  $HSIEDB01B_MIRR">>$logfile

echo " ">>$logfile



echo "Prod AGW servers (instance and mirror status)">>$logfile
echo " ">>$logfile

HSIEAGW01A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.44 "ccontrol qlist" | cut -d "^" -f 4`
HSIEAGW01A_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.44 "ccontrol qlist" | cut -d "^" -f 12`
echo "hsieagw01a:  ($HSIEDB01A_MIRR) $HSIEAGW01A_INST">>$logfile

HSIEAGW01B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.60 "ccontrol qlist" | cut -d "^" -f 4`
HSIEAGW01B_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.60 "ccontrol qlist" | cut -d "^" -f 12`
echo "hsieagw01b:  ($HSIEAGW01B_MIRR)  $HSIEAGW01B_INST">>$logfile

echo " ">>$logfile



echo "Prod Edge servers (instance up/down)">>$logfile
echo " ">>$logfile



HSIEEDGE01A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.39 "ccontrol qlist" | cut -d "^" -f 4`
HSIEEDGE01A_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.39 "ccontrol qlist" | cut -d "^" -f 12`

HSIEEDGE01A_PROD_STATES=`ssh -i swalasavage.pem swalasavage@10.247.78.39 "sudo csession VAHSEDGE001 -U %SYS "zedge1productionstatuses""`

echo "  hsedge01a: Instance:       $HSIEEDGE01A_INST">>$logfile
echo "             Mirror status:  $HSIEEDGE01A_MIRR">>$logfile
echo "             Productions:    EGVAHSRM01">>$logfile
echo "                                      $HSIEEDGE01A_PROD_STATES">>$logfile

echo " ">>$logfile


HSIEEDGE02A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.40 "ccontrol qlist" | cut -d "^" -f 4`
HSIEEDGE02A_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.40 "ccontrol qlist" | cut -d "^" -f 12`

HSIEEDGE02A_PROD_STATES=`ssh -i swalasavage.pem swalasavage@10.247.78.40 "sudo csession VAHSEDGE001 -U %SYS "zedge2productionstatuses""`

echo "  hsedge02a: Instance:       $HSIEEDGE02A_INST">>$logfile
echo "             Mirror status:  $HSIEEDGE02A_MIRR">>$logfile
echo "             Productions:    EGVAHSRM02">>$logfile
echo "                                      $HSIEEDGE02A_PROD_STATES">>$logfile

echo " ">>$logfile




HSIEEDGE03A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.41 "ccontrol qlist" | cut -d "^" -f 4`
HSIEEDGE03A_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.41 "ccontrol qlist" | cut -d "^" -f 12`

HSIEEDGE03A_PROD_STATES=`ssh -i swalasavage.pem swalasavage@10.247.78.41 "sudo csession VAHSEDGE001 -U %SYS "zedge3productionstatuses""`

echo "  hsedge03a: Instance:       $HSIEEDGE03A_INST">>$logfile
echo "             Mirror status:  $HSIEEDGE03A_MIRR">>$logfile
echo "             Productions:    EGVAHSRM03">>$logfile
echo "                                      $HSIEEDGE03A_PROD_STATES">>$logfile

echo " ">>$logfile



HSIEEDGE04A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.42 "ccontrol qlist" | cut -d "^" -f 4`
HSIEEDGE04A_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.42 "ccontrol qlist" | cut -d "^" -f 12`

HSIEEDGE04A_PROD_STATES=`ssh -i swalasavage.pem swalasavage@10.247.78.42 "sudo csession VAHSEDGE001 -U %SYS "zedge4productionstatuses""`

echo "  hsedge04a: Instance:       $HSIEEDGE04A_INST">>$logfile
echo "             Mirror status:  $HSIEEDGE04A_MIRR">>$logfile
echo "             Productions:    EGVAHSRM04">>$logfile
echo "                                      $HSIEEDGE04A_PROD_STATES">>$logfile

echo " ">>$logfile



HSIEEDGE05A_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.43 "ccontrol qlist" | cut -d "^" -f 4`
HSIEEDGE05A_MIRR=`ssh -i swalasavage.pem swalasavage@10.247.78.43 "ccontrol qlist" | cut -d "^" -f 12`

HSIEEDGE05A_PROD_STATES=`ssh -i swalasavage.pem swalasavage@10.247.78.43 "sudo csession VAHSEDGE001 -U %SYS "zedge5productionstatuses""`

echo "  hsedge05a: Instance:       $HSIEEDGE05A_INST">>$logfile
echo "             Mirror status:  $HSIEEDGE05A_MIRR">>$logfile
echo "             Productions:    EGVAHSRM05">>$logfile
echo "                                      $HSIEEDGE05A_PROD_STATES">>$logfile

echo " ">>$logfile
echo " ">>$logfile

HSIEEDGE01B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.55 "ccontrol qlist" | cut -d "^" -f 4`
echo "hsieedge01b:  $HSIEEDGE01B_INST">>$logfile
HSIEEDGE02B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.56 "ccontrol qlist" | cut -d "^" -f 4`
echo "hsieedge02b:  $HSIEEDGE02B_INST">>$logfile
HSIEEDGE03B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.57 "ccontrol qlist" | cut -d "^" -f 4`
echo "hsieedge03b:  $HSIEEDGE03B_INST">>$logfile
HSIEEDGE04B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.58 "ccontrol qlist" | cut -d "^" -f 4`
echo "hsieedge04b:  $HSIEEDGE04B_INST">>$logfile
HSIEEDGE05B_INST=`ssh -i swalasavage.pem swalasavage@10.247.78.59 "ccontrol qlist" | cut -d "^" -f 4`
echo "hsieedge05b:  $HSIEEDGE05B_INST">>$logfile




echo " ">>$logfile




echo "Prod Webservers (Apache httpd status)">>$logfile
echo " ">>$logfile
EWEB01A_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.4 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
EWEB01B_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.20 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
echo "hsrmeweb01a:  $EWEB01A_HTTPD          hsrmeweb01b:  $EWEB01B_HTTPD">>$logfile

EWEB02A_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.5 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
EWEB02B_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.21 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
echo "hsrmeweb02a:  $EWEB02A_HTTPD          hsrmeweb01b:  $EWEB02B_HTTPD">>$logfile

IWEB01A_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.6 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
IWEB01B_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.22 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
echo "hsrmiweb01a:  $IWEB01A_HTTPD          hsrmiweb01b:  $IWEB01B_HTTPD">>$logfile

IWEB02A_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.7 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
IWEB02B_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.23 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
echo "hsrmiweb02a:  $IWEB02A_HTTPD          hsrmiweb01b:  $IWEB02B_HTTPD">>$logfile

IWEB03A_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.8 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
IWEB03B_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.24 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
echo "hsrmiweb02a:  $IWEB03A_HTTPD          hsrmiweb01b:  $IWEB03B_HTTPD">>$logfile

IWEB04A_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.9 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
IWEB04B_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.25 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
echo "hsrmiweb02a:  $IWEB04A_HTTPD          hsrmiweb01b:  $IWEB04B_HTTPD">>$logfile

XWEB01A_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.10 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
XWEB01B_HTTPD=`ssh -i swalasavage.pem swalasavage@10.247.78.26 "systemctl status httpd.service" | grep "Active:" | cut -b 12-18`
echo "hsrmxweb02a:  $XWEB01A_HTTPD          hsrmxweb01b:  $XWEB01B_HTTPD">>$logfile