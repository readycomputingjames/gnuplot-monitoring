logfile="/home/swalasavage/pdfstatuscheck.log"
echo " ">>$logfile
date  >>$logfile
echo " ">>$logfile


echo "Prod Appservers (PDF & Excel Render Server states)">>$logfile

echo " ">>$logfile

APP01A_PDF=`ssh -i swalasavage.pem swalasavage@10.247.78.36 "sudo csession VAHSRM001 -U %SYS "zrenderstate""`
echo "app01a pdf,excel:  $APP01A_PDF">>$logfile

APP02A_PDF=`ssh -i swalasavage.pem swalasavage@10.247.78.37 "sudo csession VAHSRM001 -U %SYS "zrenderstate""`
echo "app02a pdf,excel:  $APP02A_PDF">>$logfile

APP03A_PDF=`ssh -i swalasavage.pem swalasavage@10.247.78.38 "sudo csession VAHSRM001 -U %SYS "zrenderstate""`
echo "app03a pdf,excel:  $APP03A_PDF">>$logfile

APP01B_PDF=`ssh -i swalasavage.pem swalasavage@10.247.78.52 "sudo csession VAHSRM001 -U %SYS "zrenderstate""`
echo "app01b pdf,excel:  $APP01B_PDF">>$logfile

APP02B_PDF=`ssh -i swalasavage.pem swalasavage@10.247.78.53 "sudo csession VAHSRM001 -U %SYS "zrenderstate""`
echo "app02b pdf,excel:  $APP02B_PDF">>$logfile

APP03B_PDF=`ssh -i swalasavage.pem swalasavage@10.247.78.54 "sudo csession VAHSRM001 -U %SYS "zrenderstate""`
echo "app03b pdf,excel:  $APP03B_PDF">>$logfile


echo " ">>$logfile
echo " ">>$logfile

#Possible states from ISC class documentation for %ZEN.Report.RenderServer and %ZEN.Report.ExcelServer

echo " ">>$logfile
echo "  Possible states:">>$logfile
echo "    0 = Inactive and ready to be started">>$logfile
echo "    1 = Active and responsive to PING">>$logfile
echo "    2 = Unresponsive (1 or both ports are in use but it is unresponsive to PING)">>$logfile
echo "    3 = Troubled (main port is not in use but it is responsive to PING)">>$logfile
echo "    4 = Error with port and/or ping port configuration">>$logfile
echo "    5 = Ping returns mismatching main port and/or server type">>$logfile



#Note:  app01a, app03a, app01b, app03b have the following ports:
#       PDF render server:    54321, 12345
#       Excel render server:  56502, 56503
#     
#       app02a, app02b have the following ports:
#       PDF render server:    56500, 56501
#       Excel render server:  56502, 56503
#
#       The ^zrenderstate routine in %SYS namespace on app02a and app02b was edited to have above ports.
#
#




echo " ">>$logfile