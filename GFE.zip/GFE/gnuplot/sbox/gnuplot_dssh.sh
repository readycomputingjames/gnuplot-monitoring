#!/bin/bash

HOST_FILE=$1
INPUT_COMMAND=$2

DATE=`date +"%m/%d/%Y"`
TIME=`date +"%H:%M"`

hippie_mon_dssh () 
{
  
   echo -ne "$DATE $TIME " >> /home/jhipp/gnuplot/sbox_mem.dat

   for HOST in `cat $HOST_FILE`
   do

   echo -ne "`/bin/ssh -i /home/jhipp/jhipp-ssh.pem -t -o ConnectTimeout=5 $HOST "/usr/bin/free -m |grep Mem" |awk '{print $3/$2 * 100.0}'` " >> /home/jhipp/gnuplot/sbox_mem.dat

   done

   echo "" >> /home/jhipp/gnuplot/sbox_mem.dat

}

hippie_mon_dssh


