#!/bin/sh

INST_NAME=`/usr/bin/ccontrol qlist |cut -d'^' -f1`

TRUE=0
FALSE=1

OTHER=2

CACHE_MIRROR_MEMBER=`echo -e "w ##class(%SYSTEM.Mirror).GetStatus()\nh" |/usr/bin/csession $INST_NAME -U %SYS |awk NR==5`

if [ "$CACHE_MIRROR_MEMBER" = "PRIMARY" ]
then
   echo "cache.mirror_primary.value $TRUE"
   echo "cache.mirror_backup.value $FALSE"
elif [ "$CACHE_MIRROR_MEMBER" = "BACKUP" ]
then
   echo "cache.mirror_primary.value $FALSE"
   echo "cache.mirror_backup.value $TRUE"
elif [ "$CACHE_MIRROR_MEMBER" != "PRIMARY" ] || [ "$CACHE_MIRROR_MEMBER" = "BACKUP" ]
then
   echo "cache.mirror_primary.value $OTHER"
   echo "cache.mirror_backup.value $OTHER"
fi

