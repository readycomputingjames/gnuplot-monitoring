#!/bin/bash

TRUE=0
FALSE=1

INST_NAME=`/usr/bin/ccontrol qlist |cut -d'^' -f1`
CACHE_STATE=`/usr/bin/ccontrol qlist |cut -d'^' -f4 |cut -d',' -f1`
NAMESPACE="%SYS"
TABLE="Security.Users"

check_cache()
{

   if [ "$CACHE_STATE" = "down" ] || [ "$CACHE_STATE" = "hung" ]
   then
      return $FALSE
   else
      return $TRUE
   fi

}

query_data()
{

output_start=14

user_count=`echo -e "d \\$SYSTEM.SQL.Shell()\nSELECT COUNT(ID) FROM $TABLE WHERE InvalidLoginAttempts != 0\nq\nh" |/usr/bin/csession $INST_NAME -U $NAMESPACE |/usr/bin/awk NR==$output_start`

if [ $user_count != 0 ]
then

   output_end=`expr $output_start + $user_count`

   mapfile -t user_list < <( echo -e "d \$SYSTEM.SQL.Shell()\nSELECT ID FROM $TABLE WHERE InvalidLoginAttempts != 0\nq\nh" |/usr/bin/csession $INST_NAME -U $NAMESPACE |/usr/bin/awk "NR==$output_start, NR==$output_end" )

   for i in ${user_list[@]};
   do
      invalid_login_count=`echo -e "d \\$SYSTEM.SQL.Shell()\nSELECT InvalidLoginAttempts FROM $TABLE WHERE ID = '$i'\nq\nh" |/usr/bin/csession $INST_NAME -U $NAMESPACE |/usr/bin/awk NR==$output_start`
      echo cache.invalid_logins.$i.value $invalid_login_count
   done

fi

}

main()
{

   if [ check_cache ]
   then
      query_data
   fi

}

main


