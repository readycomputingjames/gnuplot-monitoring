#!/bin/sh

TRUE=0
FALSE=1

SEM_LIMIT=`/usr/bin/cat /proc/sys/kernel/sem |/usr/bin/awk '{print $4}'`
SEM_USED=`/usr/bin/ipcs -us |/usr/bin/grep used |/usr/bin/awk '{print $4}'`

echo "rhel.semaphore_max.value $SEM_LIMIT"
echo "rhel.semaphore_usage.value $SEM_USED"

