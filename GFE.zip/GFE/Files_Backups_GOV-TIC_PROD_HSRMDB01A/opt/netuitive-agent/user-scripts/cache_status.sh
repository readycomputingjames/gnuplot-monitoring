#!/bin/sh

TRUE=0
FALSE=1

CACHE_STATE=`/usr/bin/ccontrol qlist |cut -d'^' -f4 |cut -d',' -f1`

if [ "$CACHE_STATE" = "down" ] || [ "$CACHE_STATE" = "hung" ]
then
   echo "cache.instance_state.value $FALSE"
else
   echo "cache.instance_state.value $TRUE"
fi

