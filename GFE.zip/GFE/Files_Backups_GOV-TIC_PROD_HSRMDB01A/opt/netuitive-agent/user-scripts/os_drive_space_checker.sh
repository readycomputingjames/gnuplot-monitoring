#!/bin/sh

INTERSYSTEMS_CAP=`/usr/bin/df -h |/usr/bin/grep "/intersystems" | /usr/bin/grep -v "/intersystems/" |/usr/bin/awk '{print $5}' |/usr/bin/cut -d'%' -f1`
VAR_LOG_CAP=`/usr/bin/df -h |/usr/bin/grep "/var/log" |/usr/bin/grep -v "/var/log/" |/usr/bin/awk '{print $5}' |/usr/bin/cut -d'%' -f1`

echo "ccra.intersystems.drive.space.value $INTERSYSTEMS_CAP"
echo "ccra.var_log.drive.value $VAR_LOG_CAP"

