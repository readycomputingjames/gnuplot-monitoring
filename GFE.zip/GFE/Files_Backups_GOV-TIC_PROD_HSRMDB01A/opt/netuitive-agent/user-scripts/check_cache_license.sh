#!/bin/sh

INST_NAME=`/usr/bin/ccontrol qlist |cut -d'^' -f1`

TRUE=0
FALSE=1

VALID="Valid"

CACHE_LICENSE_STATUS=`echo -e "w ##class(%SYSTEM.License).GetKeyStatus()\nh" |/usr/bin/csession $INST_NAME -U %SYS |awk NR==5`

if [ $CACHE_LICENSE_STATUS = $VALID ]
then
   echo "cache.license_status.value $TRUE"
else
   echo "cache.license_status.value $FALSE"
fi


