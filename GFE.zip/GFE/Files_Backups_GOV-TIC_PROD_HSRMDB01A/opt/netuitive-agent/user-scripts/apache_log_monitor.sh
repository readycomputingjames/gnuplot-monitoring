#!/bin/sh

LOG="/var/log/httpd/error_log"

ERRORS=`/bin/cat $LOG |/bin/egrep -i "scoreboard|full|space|error|MaxRequestWorkers|semaphore" |/bin/egrep -v "AH01264|AH00126|AH01630|AH00135" |/bin/wc -l`

echo "internal.apache.errors.value $ERRORS"


