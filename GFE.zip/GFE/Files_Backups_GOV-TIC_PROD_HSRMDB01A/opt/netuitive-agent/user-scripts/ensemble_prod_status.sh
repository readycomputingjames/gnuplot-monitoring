#!/bin/bash

#define eProductionStateUnknown        0
#define eProductionStateRunning        1
#define eProductionStateStopped        2
#define eProductionStateSuspended      3
#define eProductionStateTroubled       4
#define eProductionStateNetworkStopped 5

### Order - from HSRM zproductionstatuses ###
# CCRAINT
# HMFUSRMGATEWAY_HSVA
# HMFUSRMGATEWAY_MVIVA
# HMFUSRMGATEWAY_PPMSVA
# HMFUSRMROUTER
# HSRM
###

mapfile -t prod_list < <( /usr/bin/csession VAHSRM001 -U %SYS "zproductionstatuses" )

echo "cache.production.HSRMDB_CCRAINT.value ${prod_list[0]}"
echo "cache.production.HSRMDB_HSVA.value ${prod_list[1]}"
#echo "cache.production.HSRMDB_MVIVA.value ${prod_list[2]}"
echo "cache.production.HSRMDB_PPMSVA.value ${prod_list[3]}"
echo "cache.production.HSRMDB_ROUTER.value ${prod_list[4]}"
echo "cache.production.HSRMDB_HSRM.value ${prod_list[5]}"


