#!/bin/sh

LOGS_CAP=`df -h |grep " /logs" |awk '{print $5}' |cut -d'%' -f1`
ALTLOGS_CAP=`df -h |grep " /altlogs" |awk '{print $5}' |cut -d'%' -f1`
TOTAL_LOGS_CAP=$(($LOGS_CAP + $ALTLOGS_CAP))

echo "cache.logs_percentage.value $LOGS_CAP"
echo "cache.altlogs_percentage.value $ALTLOGS_CAP"
echo "cache.totallogs_percentage.value $TOTAL_LOGS_CAP"

