#!/bin/sh

TRUE=0
FALSE=1

APACHE_STATE=`/usr/bin/systemctl status httpd |/usr/bin/grep -w active`

if [ "$APACHE_STATE" ]
then
   echo "internal.apache.status.value $TRUE"
else
   echo "internal.apache.status.value $FALSE"
fi

