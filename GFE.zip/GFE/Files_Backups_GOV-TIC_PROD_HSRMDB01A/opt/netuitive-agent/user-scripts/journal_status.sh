#!/bin/sh

INST_NAME=`/usr/bin/ccontrol qlist |cut -d'^' -f1`

TRUE=0
FALSE=1

CACHE_JOURNAL_STATE=`/usr/bin/csession $INST_NAME -U %SYS "Status^JOURNAL" |egrep -i "enabled|disabled"`

if [[ $CACHE_JOURNAL_STATE = *"enabled"* ]]
then
   echo "cache.journal_status.value $TRUE"
elif [[ $CACHE_JOURNAL_STATE = *"disabled"* ]]
then
   echo "cache.journal_status.value $FALSE"
elif [[ $CACHE_JOURNAL_STATE != *"enabled"* ]] || [[ $CACHE_JOURNAL_STATE != *"disabled"* ]]
then
   echo "cache.journal_status.value $FALSE"
fi

