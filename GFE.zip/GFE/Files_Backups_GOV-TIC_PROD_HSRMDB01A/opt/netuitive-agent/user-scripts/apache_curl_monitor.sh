#!/bin/sh

TRUE=0
FALSE=1

HOSTNAME=`/usr/bin/hostname`
FQDN="$HOSTNAME.ccra.va.gov"

CA_FILE="/etc/httpd/pki/VA-Internal-FullChain.pem"

if /usr/bin/curl http://$FQDN > /dev/null 2>&1 ; then
   echo "apache.http_request.value $TRUE"
else
   echo "apache.http_request.value $FALSE"
fi

if /usr/bin/curl --cacert $CA_FILE https://$FQDN > /dev/null 2>&1 ; then
   echo "apache.https_request.value $TRUE"
else
   echo "apache.https_request.value $FALSE"
fi

