#!/bin/sh

INST_NAME=`/usr/bin/ccontrol qlist |cut -d'^' -f1`
THRESHOLD=80

PRIMARY_DIR=`echo -e "w ##class(%SYS.Journal.System).GetPrimaryDirectory()\nh" |/usr/bin/csession $INST_NAME -U %SYS |awk NR==5`
ALT_DIR=`echo -e "w ##class(%SYS.Journal.System).GetAlternateDirectory()\nh" |/usr/bin/csession $INST_NAME -U %SYS |awk NR==5`

PRIMARY_SIZE=`df -h $PRIMARY_DIR |awk '{print $5}' |cut -d'%' -f1 |tail -n +2`
ALT_SIZE=`df -h $ALT_DIR |awk '{print $5}' |cut -d'%' -f1 |tail -n +2`

if (( "$PRIMARY_SIZE" >= "$THRESHOLD" )) && (( "$ALT_SIZE" < "$THRESHOLD" ))
then
   /bin/csession $INST_NAME -U %SYS "##class(%SYS.Journal.System).SwitchDirectory()"
fi


