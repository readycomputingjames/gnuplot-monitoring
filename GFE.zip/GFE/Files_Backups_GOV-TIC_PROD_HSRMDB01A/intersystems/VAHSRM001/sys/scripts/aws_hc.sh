#!/bin/sh

/bin/sleep 55

YEAR=`/usr/bin/date +"%Y"`
HOUR=`/usr/bin/date +"%H"`
DAY=`/usr/bin/date +"%D"`

FILE="/var/log/httpd/access_log"
LOGFILE="/var/log/custom/aws_hc.log"
WEBFILE="/var/www/html/aws_hc.log"

COUNT=`/usr/bin/grep "$YEAR:$HOUR" $FILE |/bin/wc -l`
PER_SECOND=`/usr/bin/expr $COUNT / 3600`

/bin/echo -e "$DAY\t$HOUR\t$PER_SECOND" >> $LOGFILE
/bin/echo -e "$DAY\t$HOUR\t$PER_SECOND" >> $WEBFILE

