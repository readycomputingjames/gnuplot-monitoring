#!/bin/sh

TIME=`date +%s`
LOGFILE="/var/log/custom/mem_usage.log"
HISTFILE="/var/log/custom/mem_usage.log.history"

RETENTION=31
COUNT=`/bin/cat $LOGFILE |/bin/wc -l`

MEM=`/bin/free |/bin/grep Mem |/bin/awk '{printf "%.0f", ($2 - $7) / $2 * 100.0}'`

if [ $COUNT -ge $RETENTION ]
then
   ### Roll Over Data to History File ###
   # MV Line 2 to end of History File #
   /bin/awk 'NR==2' $LOGFILE >> $HISTFILE
   # Delete Line 2 #
   /bin/sed -i '2d' $LOGFILE
fi

/bin/echo "$TIME $MEM" >> $LOGFILE


