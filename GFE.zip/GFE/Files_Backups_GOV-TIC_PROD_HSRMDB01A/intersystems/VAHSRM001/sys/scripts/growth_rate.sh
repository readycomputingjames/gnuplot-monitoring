#!/bin/sh

TIME=`date +%s`
LOGFILE="/var/log/custom/intersystems_growth_rate.log"
HISTFILE="/var/log/custom/intersystems_growth_rate.log.history"

RETENTION=31
COUNT=`/bin/cat $LOGFILE |/bin/wc -l`

SIZE=`/bin/df -BG |/bin/grep intersystems |/bin/grep -v /intersystems/ |/bin/awk '{ print $2 }'`
USED=`/bin/df -BG |/bin/grep intersystems |/bin/grep -v /intersystems/ |/bin/awk '{ print $3 }'`
USAGE=`/bin/df -BG |/bin/grep intersystems |/bin/grep -v /intersystems/ |/bin/awk '{ print $5 }'`
FS=`/bin/df -BG |/bin/grep intersystems |/bin/grep -v /intersystems/ |/bin/awk '{ print $6 }'`

if [ $COUNT -ge $RETENTION ]
then
   ### Roll Over Data to History File ###
   # MV Line 2 to end of History File #
   /bin/awk 'NR==2' $LOGFILE >> $HISTFILE
   # Delete Line 2 #
   /bin/sed -i '2d' $LOGFILE
fi

/bin/echo "$TIME $SIZE $USED $USAGE $FS" >> $LOGFILE


