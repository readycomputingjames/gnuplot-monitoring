#!/bin/sh

TRUE=0
FALSE=1

INST_NAME=`/usr/bin/ccontrol qlist |cut -d'^' -f1`
CACHE_STATE=`/usr/bin/ccontrol qlist |cut -d'^' -f4 |cut -d',' -f1`
NAMESPACE="HSRM"

TIMESTAMP=`date`
LOGFILE="/var/log/custom/user_deactivate.log"

check_cache()
{

   if [ "$CACHE_STATE" = "down" ] || [ "$CACHE_STATE" = "hung" ]
   then
      echo "$INST_NAME is down or hung, not running User Deactivate Script..." >> $LOGFILE
      echo "" >> $LOGFILE
      return $FALSE
   else
      echo "$INST_NAME is up, continuing with User Deactivate Script..." >> $LOGFILE
      echo ""
      return $TRUE
   fi

}

list_users()
{

echo -e "d \$SYSTEM.SQL.Shell()\nSELECT SSUSR_Initials FROM SS_User WHERE (SSUSR_DateLastLogin + 60 < CURRENT_DATE AND SSUSR_DateTo IS NULL AND SSUSR_Initials NOT IN ('API','ccraint','hsrm','dd','demo','test+CCRA_3@id.me','test+CCRA_5@id.me','autocvo','autotriwest','autovafrm','autovafrt','autovaivm','autovaivs','autovapo','autovaro','autovarurmanage','autovarurnurse')) OR (SSUSR_DateLastLogin IS NULL AND SSUSR_DateFrom + 60 < CURRENT_DATE AND SSUSR_Active = 'Y')\nq\nh" |/usr/bin/csession $INST_NAME -U $NAMESPACE |sed -n '/SSUSR_Initials/,/Rows/p' >> $LOGFILE

}

deactivate_users()
{

echo -e "d \$SYSTEM.SQL.Shell()\nUPDATE SS_User SET SSUSR_Active = 'N', SSUSR_DateTo = DATE(CURRENT_DATE - 1) WHERE (SSUSR_DateLastLogin + 60 < CURRENT_DATE AND SSUSR_DateTo IS NULL AND SSUSR_Initials NOT IN ('API','ccraint','hsrm','dd','demo','test+CCRA_3@id.me','test+CCRA_5@id.me','autocvo','autotriwest','autovafrm','autovafrt','autovaivm','autovaivs','autovapo','autovaro','autovarurmanage','autovarurnurse')) OR (SSUSR_DateLastLogin IS NULL AND SSUSR_DateFrom + 60 < CURRENT_DATE AND SSUSR_Active = 'Y')\nq\nh" |/usr/bin/csession $INST_NAME -U $NAMESPACE >> $LOGFILE

}

main()
{

   echo "########################################" >> $LOGFILE
   echo "" >> $LOGFILE
   echo $TIMESTAMP >> $LOGFILE
   echo "" >> $LOGFILE
   echo "User Accounts that Have not Logged In Within Last 60 Days:" >> $LOGFILE
   echo "" >> $LOGFILE

   list_users

   echo "" >> $LOGFILE
   echo "Deactivating Users:" >> $LOGFILE
   echo "" >> $LOGFILE

   deactivate_users

   echo "" >> $LOGFILE
   echo "Running SELECT Query Again to Confirm:" >> $LOGFILE
   echo "" >> $LOGFILE

   list_users

   echo "" >> $LOGFILE

}

main


